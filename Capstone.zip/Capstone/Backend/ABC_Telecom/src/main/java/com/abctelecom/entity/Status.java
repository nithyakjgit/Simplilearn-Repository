package com.abctelecom.entity;

public enum Status {
	
	RAISED, ASSIGNED, WIP, RESOLVED, ESCALATED;
	

}
