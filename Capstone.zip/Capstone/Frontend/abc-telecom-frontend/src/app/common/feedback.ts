import { Ticket } from "./ticket";

export class Feedback {

    id:number;
    rating:number;
    comments:string;
    ticket:Ticket;
    
}
