import { UserDto } from './user-dto';

describe('UserDto', () => {
  it('should create an instance', () => {
    expect(new UserDto()).toBeTruthy();
  });
});
