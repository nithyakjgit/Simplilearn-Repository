import { MultiSelect } from './multi-select';

describe('MultiSelect', () => {
  it('should create an instance', () => {
    expect(new MultiSelect()).toBeTruthy();
  });
});
