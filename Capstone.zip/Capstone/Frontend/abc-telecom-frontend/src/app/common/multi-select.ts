export class MultiSelect {

    item_id:number;
    item_text:string;
    group:string;

    
}
